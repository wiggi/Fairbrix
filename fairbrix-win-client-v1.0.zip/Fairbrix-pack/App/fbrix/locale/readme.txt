put bitcoin.po and bitcoin.mo files at:
locale/<langcode>/LC_MESSAGES/bitcoin.mo and .po

.po is the sourcefile
.mo is the compiled translation
